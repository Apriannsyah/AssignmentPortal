
-- --------------------------------------------------------

--
-- Table structure for table `mata_kuliah`
--

CREATE TABLE `mata_kuliah` (
  `id_mata_kuliah` varchar(3) NOT NULL,
  `nama_mata_kuliah` varchar(100) NOT NULL,
  `dosen_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mata_kuliah`
--

INSERT INTO `mata_kuliah` (`id_mata_kuliah`, `nama_mata_kuliah`, `dosen_id`) VALUES
('BD2', 'Basis Data', 3),
('JK1', 'Jaringan Komputer', 4),
('KB0', 'Kecerdasan Buatan', 6),
('KI1', 'Keamanan Informasi', 5),
('MP2', 'Manajemen Proyek IT', 8),
('PL1', 'Rekayasa Perangkat Lunak', 7),
('PM1', 'Pemrograman Mobile', 1),
('SI1', 'Sistem Informasi', 2);
