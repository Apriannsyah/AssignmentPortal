
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `NIM` varchar(8) NOT NULL,
  `fullname` varchar(30) NOT NULL,
  `class` varchar(3) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`NIM`, `fullname`, `class`, `email`, `password`) VALUES
('06224401', 'Ahmad Zainudin', '1A', 'zainudin@gmail.com', 'Zainudin123'),
('06224402', 'Ilham Kurniawan', '1B', 'ilham.kurniawan@gmail.com', 'Ilham123'),
('06224403', 'Ragil', '1B', 'ragil@gmail.com', 'Ragil123'),
('06224405', 'Siti Aminah', '1C', 'siti.aminah@gmail.com', 'Siti123'),
('06224406', 'Eko Adi', '2A', 'eko.adi@gmail.com', 'Eko123'),
('06224407', 'Dewi Lestari', '2B', 'dewi.lestari@gmail.com', 'Dewi123'),
('06224408', 'Fajar Nugroho', '3A', 'fajar.nugroho@gmail.com', 'Fajar123'),
('06224409', 'Lina Marlina', '3B', 'lina.marlina@gmail.com', 'Lina123'),
('06224410', 'Hendra Wijaya', '4A', 'hendra.wijaya@gmail.com', 'Hendra123'),
('06224411', 'Rina Sari', '4B', 'rina.sari@gmail.com', 'Rina123'),
('06224412', 'Ahmad Fauzi', '5A', 'ahmad.fauzi@gmail.com', 'Fauzi123'),
('06224413', 'Nina Putri', '5B', 'nina.putri@gmail.com', 'Nina123');
