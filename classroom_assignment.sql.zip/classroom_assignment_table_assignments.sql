
-- --------------------------------------------------------

--
-- Table structure for table `assignments`
--

CREATE TABLE `assignments` (
  `assignment_id` int(11) NOT NULL,
  `assignment_name` varchar(255) NOT NULL,
  `subject_name` varchar(255) NOT NULL,
  `deadline_date` date NOT NULL,
  `submission_location` varchar(255) NOT NULL,
  `dosen_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `assignments`
--

INSERT INTO `assignments` (`assignment_id`, `assignment_name`, `subject_name`, `deadline_date`, `submission_location`, `dosen_id`) VALUES
(4, 'Membuat Layout Sederhana', 'Pemrograman Mobile', '2024-06-19', 'eko.kurniawan@gmail.com', 1),
(8, 'Normalisasi Database', 'Basis Data', '2024-06-19', 'budi.santoso@gmail.com', 3),
(12, 'Pengertian Sistem Informasi', 'Sistem Informasi', '2024-06-19', 'anita.wijaya@gmail.com', 2),
(16, 'Firewall', 'Keamanan Informasi', '2024-06-27', 'dedy.prasetyo@gmail.com', 5);
