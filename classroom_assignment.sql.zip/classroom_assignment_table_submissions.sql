
-- --------------------------------------------------------

--
-- Table structure for table `submissions`
--

CREATE TABLE `submissions` (
  `submission_id` int(11) NOT NULL,
  `assignment_id` int(11) DEFAULT NULL,
  `NIM` varchar(10) DEFAULT NULL,
  `student_name` varchar(30) DEFAULT NULL,
  `submission_date` date DEFAULT NULL,
  `file_location` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `submissions`
--

INSERT INTO `submissions` (`submission_id`, `assignment_id`, `NIM`, `student_name`, `submission_date`, `file_location`) VALUES
(2, 4, '06224413', 'Nina Putri', '2024-06-19', 'uploads/tugas1.pdf'),
(3, 8, '06224406', 'Eko Adi', '2024-06-19', 'uploads/tugas3.pdf');
