
-- --------------------------------------------------------

--
-- Table structure for table `users_dosen`
--

CREATE TABLE `users_dosen` (
  `id_dosen` int(11) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `mata_kuliah` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users_dosen`
--

INSERT INTO `users_dosen` (`id_dosen`, `nama`, `mata_kuliah`, `email`, `password`) VALUES
(1, 'Eko Kurniawan, S.Kom., M.Kom', 'Pemrograman Mobile', 'eko.kurniawan@gmail.com', 'eko123'),
(2, 'Anita Wijaya, S.Kom., M.T.', 'Sistem Informasi', 'anita.wijaya@gmail.com', 'anita123'),
(3, 'Budi Santoso, S.Kom.', 'Basis Data', 'budi.santoso@gmail.com', 'budi123'),
(4, 'Citra Dewi, S.Kom.', 'Jaringan Komputer', 'citra.dewi@gmail.com', 'citra123'),
(5, 'Dedy Prasetyo, S.Kom., M.Kom.', 'Keamanan Informasi', 'dedy.prasetyo@gmail.com', 'dedy123'),
(6, 'Gita Wijaya, S.Kom., M.Kom.', 'Kecerdasan Buatan', 'gita.wijaya@gmail.com', 'gita123'),
(7, 'Hendra Gunawan, S.Kom.', 'Rekayasa Perangkat L', 'hendra.gunawan@gmail.com', 'hendra123'),
(8, 'Iwan Setiawan, S.Kom.', 'Manajemen Proyek TI', 'iwan.setiawan@gmail.com', 'iwan123');
